package com.example.amazonminiapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmazonMiniapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmazonMiniapiApplication.class, args);
	}

}
