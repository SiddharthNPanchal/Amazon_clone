package com.example.amazonminiapi.model;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface CategoryrRepository extends MongoRepository <Category, String>{

}
