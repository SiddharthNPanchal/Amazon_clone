package com.example.amazonminiapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonMiniapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
